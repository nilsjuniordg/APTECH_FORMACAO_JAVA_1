/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Aluno 004
 */
public class Main {

    public static void main(String[] args) {

        double a = 0;



        while (true) {



            try {

                Scanner leitor = new Scanner(System.in);
                System.out.println("digite o valor de a: ");
                a = leitor.nextDouble();
                System.out.println("a é um número");
                break;


            } catch (ArithmeticException exc) {
                System.out.println("a é uma palavra!");
                System.out.println("tente novamente!");
                System.out.println("=============");

            }
        }


        System.out.println("continuando o programa...");



    }
}
