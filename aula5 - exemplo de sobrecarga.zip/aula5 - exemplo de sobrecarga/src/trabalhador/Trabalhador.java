/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalhador;

/**
 *
 * @author Aluno 004
 */
public class Trabalhador {
    
    
    //definir alguns atributos
    
    String nome;
    double salario;
    double bonus;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }
    
    
}
