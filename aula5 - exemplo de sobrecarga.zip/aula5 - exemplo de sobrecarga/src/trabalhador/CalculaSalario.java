/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalhador;

/**
 *
 * @author Aluno 004
 */
public class CalculaSalario {
    
    //criar os métodos
    
    public double calcsal (double valor)
            
    {
        return valor;
    }
    
    //sobrecarga do método calcsal
    public double calsal (double salario, double bonus)
    {
       return salario+bonus; 
    }
    
}
