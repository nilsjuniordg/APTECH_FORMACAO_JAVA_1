/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import trabalhador.CalculaSalario;
import trabalhador.Trabalhador;

/**
 *
 * @author Aluno 004
 */
public class Main {
    public static void main(String[] args) {
        
        CalculaSalario cal = new CalculaSalario();
        Trabalhador T1 = new Trabalhador();
        Trabalhador T2 = new Trabalhador();
        
        T1.setNome("Henrique");
        T1.setSalario(1500);
        T1.setBonus(0);
        
        T2.setNome("Luciana");
        T2.setSalario(2500);
        T2.setBonus(300);
        
        //calcular o salário de cada um
        
        double salario1;
        double salario2;
        
        //chamando o método de CalculaSalario
        
        salario1 = cal.calcsal(T1.getSalario());
        salario2 = cal.calsal(T2.getSalario(), T2.getBonus());
        
        System.out.println(T1.getNome()+ " recebe " + salario1);
        System.out.println(T2.getNome()+ " recebe " + salario2 );
        
      
        
    }
    
}
