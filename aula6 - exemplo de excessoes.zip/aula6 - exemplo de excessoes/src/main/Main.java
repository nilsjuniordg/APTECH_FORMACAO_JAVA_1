/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author Aluno 004
 */
public class Main {
    public static void main(String[] args) {
        
        
        /**
        *double a;
        *System.out.println("o valor de a é " +a);
        *a=20/0; 
       
         */
        
        Cavalo c1 = new Cavalo();
        
        
    }
    
}
