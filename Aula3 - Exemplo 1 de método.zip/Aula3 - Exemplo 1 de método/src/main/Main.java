/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import cachorros.Cachorros;



/**
 *
 * @author Aluno 004
 */
public class Main {
    public static void main(String[] args) {
        Cachorros c1 = new Cachorros ();
        c1.latir();
        c1.latir();
        c1.latir();
        
        double p1;
        p1=12.6;
        double comida;
        comida = 2.3;
        
        double pesofinal;
        pesofinal = c1.engordar(p1, comida)
                System.out.println("o peso final é" + pesofinal);
          
        
        
    }
    
}
