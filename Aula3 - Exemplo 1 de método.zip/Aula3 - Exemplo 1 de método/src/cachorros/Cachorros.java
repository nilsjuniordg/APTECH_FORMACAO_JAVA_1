/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cachorros;

/**
 *
 * @author Aluno 004
 */
public class Cachorros {
    
    //método latir
    //void -> não retorna valor
    //não tem argumentos -> não recebe nenhum valor
    
    public void latir()
    {
    
            System.out.println("auauau");
            
            //método engordar
            //double -> retorna um valor do tipo double
            //tem 1 argumento -> recebe 1 valor
    }
            public double engordar (double peso, double qtd)
            {
                
                double resultado;
                resultado = peso + qtd;
                return resultado;
            }
}
