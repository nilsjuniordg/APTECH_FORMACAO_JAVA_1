/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import veiculos.Aviao;
import veiculos.Carro;
import veiculos.Moto;

/**
 *
 * @author Aluno 004
 */
public class Main {
    public static void main(String[] args) {
         
        
        Aviao a1 = new Aviao();
        Carro c1 = new Carro();
        Moto m1 = new Moto();
        
        a1.acelerar();
        c1.acelerar();
        m1.acelerar();
        
        a1.brekar();
        c1.brekar();
        m1.brekar();
        
    }
    
}
