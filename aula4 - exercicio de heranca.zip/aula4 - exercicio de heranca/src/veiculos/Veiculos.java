/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package veiculos;

/**
 *
 * @author Aluno 004
 */
public class Veiculos {
    String marca;
    String cor;
    double preco;
    int ano;

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }
    
   
    public void acelerar()
    {
        System.out.println("vrum, vrum, vrum");
    }
     
     public void brekar()
    {
        System.out.println("brekando");
    }
    
    
}
