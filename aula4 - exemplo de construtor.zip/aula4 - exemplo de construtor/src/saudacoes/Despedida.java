/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package saudacoes;

/**
 *
 * @author Aluno 004
 */
public class Despedida {

    public Despedida() {
        System.out.println("Você tem certeza que deseja sair??");
        System.out.println("Ok, a Aptech agradece sua visita!");
        
        
    }
    
    
}
