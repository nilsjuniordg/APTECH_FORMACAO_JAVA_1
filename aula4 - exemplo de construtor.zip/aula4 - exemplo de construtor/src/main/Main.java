/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import saudacoes.Bemvindo;
import saudacoes.Despedida;

/**
 *
 * @author Aluno 004
 */
public class Main {
    public static void main(String[] args) {
        
         //instanciar criando objeto
        
        Bemvindo b1 = new Bemvindo();
        
        
        //instanciar sem criar objeto
        
        new Bemvindo();
        
         //instanciar criando objeto
        
        Despedida d1 = new Despedida();
        
        
        //instanciar sem criar objeto
        
        new Despedida ();
        
        
        
        
        
        
        
    }
    
}
