/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.util.Scanner;



/**
 *
 * @author Aluno 004
 */
public class Main {
    
    public static void main(String[] args) {
        
        int a=0;
        int b=0;
        int resp=0;
        
        Scanner leitor = new Scanner(System.in);
        System.out.println("digite o valor de a: ");
        a=leitor.nextInt();
        
        System.out.println("digite o valor de b: ");
        b=leitor.nextInt();
        
        
        if (b == 0)
        {
                System.out.println("não pode dividir por zero");
        }
        
        else
        {
        
            
            resp = a/b;
            System.out.println("a divisão vale " + resp);
      
        }
        
        System.out.println("continuando o programa...");
          
       
    
    }
    }
    
