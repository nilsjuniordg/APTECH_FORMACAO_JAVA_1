/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import animais.Borboleta;
import animais.Cachorro;
import animais.Cobra;
import animais.Coelho;

/**
 *
 * @author Aluno 004
 */
public class Main {
    
    public static void main(String[] args) {
        
        Borboleta b1 = new Borboleta();
        Cachorro c1 = new Cachorro();
        Cobra cob1 = new Cobra();
        Coelho coe1 = new Coelho();
        
        //você pode chamar os métodos agora se quiser
        
        
        
        
    }
    
}
