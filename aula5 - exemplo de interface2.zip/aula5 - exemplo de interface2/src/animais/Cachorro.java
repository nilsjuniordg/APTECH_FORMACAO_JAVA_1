/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package animais;

/**
 *
 * @author Aluno 004
 */
public class Cachorro extends Animais implements IPular, Icorrer, Imorder{

    @Override
    public void pular() {
        System.out.println("pulando");
    }

    @Override
    public void correr() {
        System.out.println("correndo");
    }

    @Override
    public void morder() {
        System.out.println("mordendo");
    }
    
}
