/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package animais;

    
/**
 *
 * @author Aluno 004
 */
public class Animais {
    
        
        String nome;
        double tamanho;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getTamanho() {
        return tamanho;
    }

    public void setTamanho(double tamanho) {
        this.tamanho = tamanho;
    }
        
        
    
        
    }

