/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package animais;

/**
 *
 * @author Aluno 004
 */
public class Coelho extends Animais implements IPular{

    @Override
    public void pular() {
        System.out.println("pulando");
    }
    
    
    
}
