/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package animais;

/**
 *
 * @author Aluno 004
 */
public class Cobra extends Animais implements Irrastar, Imorder, IPular{

    @Override
    public void arrastar() {
        System.out.println("arrastando");
    }

    @Override
    public void morder() {
        System.out.println("mordendo");
    }

    @Override
    public void pular() {
        System.out.println("pulando");
    }
    
    
    
}
