/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import saudacoes.Menu;



/**
 *
 * @author Aluno 004
 */
public class Main {
    public static void main(String[] args) {
        
        new Menu();
        
        
        
        
    }
    
}
