/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import animais.Cachorro;
import animais.Gato;
import animais.Lobo;
import animais.Passaro;

/**
 *
 * @author Aluno 004
 */
public class Main {
    public static void main(String[] args) {
        Cachorro c1 = new Cachorro();
        Gato g1 = new Gato();
        Lobo L1 = new Lobo();
        Passaro p1 = new Passaro();
        
        p1.piar();
    }
    
}
