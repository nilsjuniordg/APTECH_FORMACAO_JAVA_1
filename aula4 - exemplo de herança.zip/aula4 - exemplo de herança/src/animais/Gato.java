/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package animais;

/**
 *
 * @author Aluno 004
 */
public class Gato extends Animais {
    public void miar()
    {
        System.out.println("miau miau miau!!");
         
    }
    
    
}
