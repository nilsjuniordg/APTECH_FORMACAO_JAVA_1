/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package animais;

/**
 *
 * @author Aluno 004
 */
public class Passaro extends Animais {
    public void piar()
    { 
        System.out.println("piu piu piu!!");
    }
}
