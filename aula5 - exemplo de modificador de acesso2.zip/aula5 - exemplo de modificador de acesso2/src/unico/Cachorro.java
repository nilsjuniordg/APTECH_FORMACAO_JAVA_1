/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package unico;

/**
 *
 * @author Aluno 004
 */
public class Cachorro {
    protected String nome;
    protected int idade;
    
}
