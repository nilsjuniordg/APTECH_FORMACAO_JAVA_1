/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package unico;

/**
 *
 * @author Aluno 004
 */
public class Main {
    public static void main(String[] args) {
        Cachorro c1 = new Cachorro();
        c1.nome = "dog";
        c1.idade = 10;
    }
    
}
