/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import profissoes.Bombeiro;
import profissoes.Professor;
import profissoes.Vendedor;

/**
 *
 * @author Aluno 004
 */
public class Main {
    public static void main(String[] args) {
        
        Bombeiro b1 = new Bombeiro();
        Professor p1 = new Professor();
        Vendedor v1 = new Vendedor();
        
        b1.chegar();
        p1.chegar();
        v1.chegar();
        
        
    }
    
}
