/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package profissoes;

/**
 *
 * @author Aluno 004
 */
public class Vendedor extends Profissoes {

    @Override
    public void chegar() {
        System.out.println("chega de madrugada");
    }
    
}
