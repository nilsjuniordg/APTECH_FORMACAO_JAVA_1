/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package profissoes;

/**
 *
 * @author Aluno 004
 */
public abstract class Profissoes {
    
    //método abstrato
    
    public abstract void chegar();
    
    
}
