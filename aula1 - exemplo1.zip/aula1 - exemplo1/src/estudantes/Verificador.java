/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package estudantes;

/**
 *
 * @author Aluno 004
 */
public class Verificador {
    // criar um método para ver quem é mais velho
    
    
    public void quemMaisVelho (double idade1, double idade2)

    {
    
        if (idade1>idade2)
        {
            
            System.out.println("A pessoa 1 é mais velha que a pessoa 2.");
        }
        
        else
        {
             System.out.println("A pessoa 2 é mais velha que a pessoa 1.");
        }
    }   
        
}
