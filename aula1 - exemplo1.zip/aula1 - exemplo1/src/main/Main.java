/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import estudantes.Estudantes;
import estudantes.Verificador;

/**
 *
 * @author Aluno 004
 */
public class Main {
    public static void main(String[] args) {
        Estudantes el = new Estudantes();
        Estudantes el2 = new Estudantes();
        
        el.setNome("Lucas");
        el.setIdade(13);
        
        el2.setNome("Gabriela");
        el2.setIdade(16);
        
        Verificador vi = new Verificador();
        
        vi.quemMaisVelho(el.getIdade(), el2.getIdade());
        
        
        
        
    }
    
}
