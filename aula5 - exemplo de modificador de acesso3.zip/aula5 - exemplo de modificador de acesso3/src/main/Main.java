/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import cachorro.Cachorro;

/**
 *
 * @author Aluno 004
 */
public class Main {
    public static void main(String[] args) {
        Cachorro cachorro = new Cachorro();
        //mostra as frases, por causa do construtor
        //dentro da classe Cachorro.
        // não consegue atribuir valores para c1
        // pois, os atributos da classe Cachorro
        // estão encapsulados com o modificador de acesso private .
        
        
    }
    
}
