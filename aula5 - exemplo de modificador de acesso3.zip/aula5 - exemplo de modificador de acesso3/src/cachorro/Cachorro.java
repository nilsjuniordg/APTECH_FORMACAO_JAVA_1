/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cachorro;

/**
 *
 * @author Aluno 004
 */
public class Cachorro {
    
    private String nome;
    private int idade;

    public Cachorro() {
        
        nome = "dog";
        idade = 30;
        System.out.println("nome do cachorro é " + nome);
        System.out.println("idade é " + idade);
    }
    
    
    
}
