/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import animais.Animais;
import animais.Cachorros;
import animais.Gatos;

/**
 *
 * @author Aluno 004
 */
public class Main {
    public static void main(String[] args) {
        Cachorros c1 = new Cachorros();
        Gatos g1 = new Gatos();
        
        c1.barulho();
        g1.barulho();
        
        //dá erro, pois a classe animais
       // é uma classe abstrata
        
        Animais a1 = new Animais();
        a1.barulho();
        
        
        
        
    }
    
}
