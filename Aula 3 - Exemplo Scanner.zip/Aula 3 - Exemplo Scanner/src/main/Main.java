/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.util.Scanner;
import veiculos.Carros;
import veiculos.Motos;

/**
 *
 * @author Aluno 004
 */
public class Main {
    public static void main(String[] args) {
       Carros c1 = new Carros();
//       
//       Scanner leitor = new Scanner (System.in);
//        System.out.println("Qual a cor do carro1?");
//        c1.setCor(leitor.nextLine());
//        System.out.println("a cor do carro1 é " + c1.getCor());
//       
//        double parcela10;
//        System.out.println("Qual o valor do carro?");
//        c1.setPreco(leitor.nextDouble());
//        
//        System.out.println("o valor do carro é " + c1.getPreco());
//        parcela10 = c1.getPreco()/10;
//        System.out.println(" o valor do carro1 parcelado em 10 vezes é " + parcela10);
//        
        //motos====================================================================
        
        
        Scanner leitor2 = new Scanner (System.in);
        Motos m1= new Motos ();
        
        System.out.println("Qual a marca da moto?");
        m1.setMarca(leitor2.nextLine());
        System.out.println("a marca da moto é " + m1.getMarca());
        
        
        System.out.println("Qual a cilindrada da moto?");
        m1.setCilindrada(leitor2.nextInt());
        System.out.println("a cilindrada da moto é " + m1.getCilindrada());
        
        
        
    }
    
}
