/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package armas;

/**
 *
 * @author Aluno 004
 */
public class Pistolas_automaticas extends Pistolas{
    
    private int velocidade;
    
    
    
    @Override
    public void atirar()
    {
        
        super.atirar();
        velocidade=200;
        System.out.println("velocidade: "+200);
    }
    
    
    
        public void disparar1()
    
        {
                super.atirar();
        
                
        }
          public void disparar2()
          {
                this.atirar();

          
}
    }
    

