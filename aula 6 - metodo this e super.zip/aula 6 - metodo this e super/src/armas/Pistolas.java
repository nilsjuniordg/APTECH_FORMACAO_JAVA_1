/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package armas;

/**
 *
 * @author Aluno 004
 */
public class Pistolas {
    
    protected String marca;
    protected int balas;
    protected double calibre;
    
    public void atirar(){
        
        marca = "winchester";
        balas = 9;
        calibre = 0.44;
        
        System.out.println("Arma: " +marca);
        System.out.println("Balas: " +balas);
        System.out.println("Calibre: " +calibre);
        
        
        
    }
    
}
