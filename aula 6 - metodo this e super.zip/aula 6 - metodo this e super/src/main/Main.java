/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import armas.Pistolas_automaticas;

/**
 *
 * @author Aluno 004
 */
public class Main {
    
    public static void main(String[] args) {
        
        Pistolas_automaticas p1 = new Pistolas_automaticas();
        
        p1.disparar1();
        
        System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
        p1.disparar2();
        
    }
    
}
