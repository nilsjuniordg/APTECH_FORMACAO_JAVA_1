/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import pessoas.Medico;
import pessoas.ProgramadorJr;
import pessoas.ProgramadorSr;

/**
 *
 * @author Aluno 004
 */
public class Main {
    
    public static void main(String[] args) {
        
        Medico m1 = new Medico ();
        ProgramadorJr p1 = new ProgramadorJr ();
        ProgramadorSr p2 = new ProgramadorSr ();
        
        
        
        
        
        
        
        
    }
    
}
