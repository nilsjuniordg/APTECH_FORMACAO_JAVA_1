/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoas;

/**
 *
 * @author Aluno 004
 */
public class ProgramadorSr extends Pessoas implements ISaberProgramar{

    @Override
    public void programar() {
        System.out.println("já sabe programar muito bem!");
    }

    @Override
    public void digitar() {
        System.out.println("tem um domínio completo para digitar!");
    }
    
    
}
