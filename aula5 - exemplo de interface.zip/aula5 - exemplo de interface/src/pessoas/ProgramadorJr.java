/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoas;

/**
 *
 * @author Aluno 004
 */
public class ProgramadorJr extends Pessoas implements ISaberProgramar{

    @Override
    public void programar() {
        System.out.println("está aprendendo a programar");
    }

    @Override
    public void digitar() {
        System.out.println("sabe digitar");
    }
    
}
