/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoas;

/**
 *
 * @author Aluno 004
 */
public interface ISaberProgramar {
    
    public void programar();
    public void digitar();
    
}
