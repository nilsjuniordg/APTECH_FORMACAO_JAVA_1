/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import funcionarios.Professores;


/**
 *
 * @author Aluno 004
 */
public class Main {
    public static void main(String[] args) {
        Professores p1 = new Professores ();
        
        p1.setNome ("Lucas");
        p1.setIdade (45);
        p1.setMateria("Java");
        
        System.out.println("Nome do professor é" +p1.getNome());
        System.out.println("A idade do professor é" + p1.getIdade());
    }
    
}
