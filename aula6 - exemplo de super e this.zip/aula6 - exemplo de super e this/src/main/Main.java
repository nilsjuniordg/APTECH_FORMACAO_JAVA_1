/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import familia.Filho;

/**
 *
 * @author Aluno 004
 */
public class Main {
    public static void main(String[] args) {
        
        Filho f1 = new Filho();
        f1.mostrarNomes();
    }
    
}
