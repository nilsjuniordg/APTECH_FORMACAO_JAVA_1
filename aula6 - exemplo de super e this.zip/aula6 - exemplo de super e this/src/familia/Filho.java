/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package familia;

/**
 *
 * @author Aluno 004
 */
public class Filho extends Pai{

    public Filho() {
        
        // nome do pai
        
        super.nome = "João";
                
        // nome do filho
        this.nome = "Daniel";
        
        /**tente mexer no salário
        
        super.salario=1000;
        
        dá um erro, pois salário e atributo
        private da Classe Pai
         
       */
        
        
        //criar um método para mostrar os nomes
        
        public void mostrarNomes()
                
        {
            System.out.println("Nome do Pai é " + super.nome);
            System.out.println("Nome do Filho é " + this.nome);
        }
        
}
    



