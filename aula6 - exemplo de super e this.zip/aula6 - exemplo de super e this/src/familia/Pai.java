/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package familia;

/**
 *
 * @author Aluno 004
 */
public class Pai {
    
    protected String nome;
    protected int idade;
    private double salario;
    public String profissao;
    
    
    
}
