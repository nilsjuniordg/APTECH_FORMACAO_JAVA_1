/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import cachorro.Cachorro;

/**
 *
 * @author Aluno 004
 */
public class Main {
    
    public static void main(String[] args) {
        
        Cachorro c1 = new Cachorro();
        c1.idade = 10;
        c1.nome = "dog";
        
        
        System.out.println(" o nome do c1 é "+c1.nome);
    }
    
}
