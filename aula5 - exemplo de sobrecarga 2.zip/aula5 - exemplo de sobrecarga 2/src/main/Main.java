/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import calculadora.Calculadora;

/**
 *
 * @author Aluno 004
 */
public class Main {
    public static void main(String[] args) {
        
       Calculadora c1 = new Calculadora();
       
       
       double r1;
       r1 = c1.somar(45, 658);
        System.out.println("r1 vale " + r1);
        
        double r2;
        r2 = c1.somar(45, 658, 45);
        
        System.out.println("r2 vale " +r2);
              
       
       
    }
    
}
