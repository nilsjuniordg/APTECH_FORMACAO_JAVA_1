/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadora;

/**
 *
 * @author Aluno 004
 */
public class Calculadora {
    
    public double somar (double x, double y, double z)
           
           
    {
        return x+y+z;
    }
         
      //sobrecarga do método Calculadora
    public double somar (double a, double b)
            
    {
        
        return a+b;
    }
    
}
